import express from 'express';
import nodemailer from 'nodemailer';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3001;

// Security Middleware
app.use(helmet()); // Set security HTTP headers

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per `window` (here, per 15 minutes)
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: { success: false, message: 'Too many requests, please try again later.' }
});

// Apply rate limiting to all requests (or just /api if preferred)
app.use('/api', limiter);

// Middleware
// Configure CORS to allow requests from your frontend domain
// In production, replace '*' with your actual domain, e.g., 'https://your-domain.com'
app.use(cors({
  origin: process.env.FRONTEND_URL || '*', // Allow all origins by default or use env var
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '50mb' })); // Increase limit for base64 images if sent as JSON
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Configure Multer for handling file uploads (if we decide to send as FormData)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit per file
});

// Email Transporter Configuration
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.titan.email',
  port: parseInt(process.env.SMTP_PORT || '465'),
  secure: true, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || 'order@timagnet.com',
    pass: process.env.SMTP_PASS_B64 ? Buffer.from(process.env.SMTP_PASS_B64, 'base64').toString('utf-8') : process.env.SMTP_PASS,
  },
});

// Verify connection configuration
transporter.verify(function (error, success) {
  if (error) {
    console.log('SMTP Connection Error:', error);
  } else {
    console.log('SMTP Server is ready to take our messages');
  }
});

// API Routes
app.post('/api/order', upload.array('images'), async (req, res) => {
  try {
    const { 
      productName, 
      productDimensions, 
      quantity, 
      totalPrice, 
      deliveryOption, 
      customerEmail, 
      customerName,
      customerAddress, // JSON string if sent via FormData
      imagesData // If sending base64 strings directly in JSON body instead of FormData files
    } = req.body;

    let attachments = [];

    // Handle images - either from Multer (req.files) or JSON body (req.body.imagesData)
    if (req.files && req.files.length > 0) {
      attachments = req.files.map((file, index) => ({
        filename: `magnet-${index + 1}${path.extname(file.originalname) || '.png'}`,
        content: file.buffer,
      }));
    } else if (imagesData && Array.isArray(imagesData)) {
        // If images are sent as base64 strings in the body
        attachments = imagesData.map((dataUrl, index) => {
            // dataUrl is like "data:image/png;base64,iVBORw0KGgo..."
            const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
            if (!matches || matches.length !== 3) {
                return null;
            }
            return {
                filename: `magnet-${index + 1}.${matches[1].split('/')[1]}`,
                content: Buffer.from(matches[2], 'base64')
            };
        }).filter(Boolean);
    }

    // Parse address if it's a string (when using FormData)
    let addressObj = customerAddress;
    if (typeof customerAddress === 'string') {
        try {
            addressObj = JSON.parse(customerAddress);
        } catch (e) {
            addressObj = {};
        }
    }

    const addressText = deliveryOption === 'shipping' 
      ? `
        Name: ${addressObj.name || customerName}
        Street: ${addressObj.street}
        City: ${addressObj.city}
        Province: ${addressObj.province}
        Postal Code: ${addressObj.postalCode}
      `
      : 'Pickup at location';

    // Email to Owner
    const ownerMailOptions = {
      from: `"Ti'Magnet Order System" <${process.env.SMTP_USER}>`,
      to: process.env.SMTP_USER, // Send to self/owner
      subject: `New Order: ${quantity} x ${productName}`,
      html: `
        <h2>New Order Received</h2>
        <p><strong>Product:</strong> ${productName} (${productDimensions})</p>
        <p><strong>Quantity:</strong> ${quantity}</p>
        <p><strong>Total Price:</strong> ${totalPrice} €</p>
        <p><strong>Delivery Method:</strong> ${deliveryOption}</p>
        <p><strong>Customer Email:</strong> ${customerEmail}</p>
        
        <h3>Delivery Details:</h3>
        <pre style="font-family: sans-serif;">${addressText}</pre>
        
        <p>See attached images for the order.</p>
      `,
      attachments: attachments,
    };

    // Email to Customer
    const customerMailOptions = {
      from: `"Ti'Magnet" <${process.env.SMTP_USER}>`,
      to: customerEmail,
      subject: `Order Confirmation - Ti'Magnet`,
      html: `
        <h2>Thank you for your order!</h2>
        <p>We have received your order for <strong>${quantity} x ${productName}</strong>.</p>
        <p><strong>Total Price:</strong> ${totalPrice} €</p>
        <p><strong>Delivery Method:</strong> ${deliveryOption}</p>
        
        <p>We will process your order shortly.</p>
        
        <p>Best regards,<br>The Ti'Magnet Team</p>
      `,
    };

    // Send emails
    console.log('Sending email to owner...');
    await transporter.sendMail(ownerMailOptions);
    
    console.log('Sending confirmation to customer...');
    await transporter.sendMail(customerMailOptions);

    res.status(200).json({ success: true, message: 'Order placed successfully!' });

  } catch (error) {
    console.error('Error processing order:', error);
    res.status(500).json({ success: false, message: 'Failed to process order.', error: error.message });
  }
});

app.get('/api/health', (req, res) => {
  res.send('Ti\'Magnet API Server Running');
});

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../dist')));

// The "catchall" handler: for any request that doesn't
// match one above, send back React's index.html file.
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
